import SwiftUI
import AppKit
import UniformTypeIdentifiers

struct SavedScript: Codable, Identifiable {
    var id = UUID()
    var name: String
    var code: String
}

final class ScriptLibrary: ObservableObject {
    @Published private(set) var scripts: [SavedScript] = []
    @Published var error: String?
    private let file: URL
    private var canSave = true

    init() {
        let directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("AlexiaHubPersonal", isDirectory: true)
        file = directory.appendingPathComponent("scripts.json")
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: file.path) {
                scripts = try JSONDecoder().decode([SavedScript].self, from: Data(contentsOf: file))
            }
        } catch {
            canSave = false
            self.error = "Could not read your script library. Your saved file has been preserved. \(error.localizedDescription)"
        }
    }

    func save(_ script: SavedScript) throws {
        var updated = scripts
        if let index = updated.firstIndex(where: { $0.id == script.id }) {
            updated[index] = script
        } else {
            updated.append(script)
        }
        try persist(updated)
    }

    func delete(_ script: SavedScript) throws {
        try persist(scripts.filter { $0.id != script.id })
    }

    private func persist(_ updated: [SavedScript]) throws {
        guard canSave else {
            throw NSError(domain: "AlexiaHub", code: 1, userInfo: [NSLocalizedDescriptionKey: "Restart after restoring or repairing scripts.json in Application Support/AlexiaHubPersonal."])
        }
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        try encoder.encode(updated).write(to: file, options: .atomic)
        scripts = updated
    }
}

@main
struct AlexiaPersonalApp: App {
    var body: some Scene {
        WindowGroup("Alexia HUB — Personal") {
            PersonalHub()
                .frame(minWidth: 780, minHeight: 560)
                .preferredColorScheme(.dark)
        }
    }
}

struct PersonalHub: View {
    @StateObject private var library = ScriptLibrary()
    @StateObject private var updater = PersonalUpdater()
    @State private var page = "scripts"
    @State private var search = ""
    @State private var editing: SavedScript?
    @State private var pendingDelete: SavedScript?
    @State private var status = ""
    @AppStorage("personalLauncherFile") private var launcherPath = ""

    private var filteredScripts: [SavedScript] {
        library.scripts.filter { search.isEmpty || $0.name.localizedCaseInsensitiveContains(search) }
    }

    var body: some View {
        HStack(spacing: 0) {
            sidebar
            Divider()
            VStack(alignment: .leading, spacing: 20) {
                if page == "scripts" { scriptPage }
                else if page == "apps" { appsPage }
                else { UpdatesPage(updater: updater) }
                Spacer(minLength: 0)
                Text(status).font(.callout).foregroundStyle(.secondary)
                    .textSelection(.enabled).accessibilityLabel("Status: \(status)")
            }
            .padding(30)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
        .background(Color(nsColor: .windowBackgroundColor))
        .task {
            await updater.checkAutomatically()
            while !Task.isCancelled {
                do { try await Task.sleep(nanoseconds: 3_600_000_000_000) }
                catch { return }
                await updater.checkAutomatically()
            }
        }
        .sheet(item: $editing) { script in
            ScriptEditor(script: script) { try library.save($0) }
        }
        .alert("Delete script?", isPresented: Binding(
            get: { pendingDelete != nil },
            set: { if !$0 { pendingDelete = nil } }
        )) {
            Button("Cancel", role: .cancel) { pendingDelete = nil }
            Button("Delete", role: .destructive) {
                guard let script = pendingDelete else { return }
                do {
                    try library.delete(script)
                    status = "Deleted \(script.name)."
                } catch { library.error = error.localizedDescription }
                pendingDelete = nil
            }
        } message: {
            Text("Remove \(pendingDelete?.name ?? "this script") from your saved library?")
        }
        .alert("Unable to complete action", isPresented: Binding(
            get: { library.error != nil },
            set: { if !$0 { library.error = nil } }
        )) {
            Button("OK") { library.error = nil }
        } message: { Text(library.error ?? "") }
    }

    private var sidebar: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("ALEXIA HUB").font(.title2.bold()).foregroundStyle(.cyan)
            Text("PERSONAL").font(.caption).foregroundStyle(.secondary)
            Divider().padding(.vertical, 8)
            Button { page = "scripts" } label: {
                Label("Scripts", systemImage: "chevron.left.forwardslash.chevron.right")
                    .frame(maxWidth: .infinity, alignment: .leading).padding(10)
                    .background(page == "scripts" ? Color.cyan.opacity(0.15) : Color.clear)
                    .cornerRadius(8)
            }
            Button { page = "apps" } label: {
                Label("Apps", systemImage: "square.grid.2x2")
                    .frame(maxWidth: .infinity, alignment: .leading).padding(10)
                    .background(page == "apps" ? Color.cyan.opacity(0.15) : Color.clear)
                    .cornerRadius(8)
            }
            Button { page = "updates" } label: {
                Label(updater.availableVersion == nil ? "Updates" : "Update available", systemImage: "arrow.triangle.2.circlepath")
                    .frame(maxWidth: .infinity, alignment: .leading).padding(10)
                    .background(page == "updates" ? Color.cyan.opacity(0.15) : Color.clear)
                    .cornerRadius(8)
            }
            Spacer()
            Text("Saved on this Mac").font(.caption).foregroundStyle(.secondary)
        }
        .buttonStyle(.plain).padding(22).frame(width: 210)
        .frame(maxHeight: .infinity)
    }

    private var scriptPage: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Text("Script library").font(.largeTitle.bold())
                Spacer()
                Button { editing = SavedScript(name: "", code: "") } label: {
                    Label("Add script", systemImage: "plus")
                }.buttonStyle(.borderedProminent).tint(.cyan)
            }
            TextField("Search scripts", text: $search).textFieldStyle(.roundedBorder)
            ScrollView {
                if library.scripts.isEmpty {
                    VStack(spacing: 14) {
                        Image(systemName: "doc.badge.plus").font(.system(size: 42)).foregroundStyle(.cyan)
                        Text("Your scripts live here").font(.title3.bold())
                        Text("Press Add script, enter a name, and paste your script.").foregroundStyle(.secondary)
                    }.frame(maxWidth: .infinity).padding(.vertical, 70)
                } else if filteredScripts.isEmpty {
                    Text("No scripts match your search.").padding(30)
                }
                LazyVStack(spacing: 14) {
                    ForEach(filteredScripts) { script in
                        GroupBox {
                            VStack(alignment: .leading, spacing: 18) {
                                Label(script.name, systemImage: "doc.text.fill").font(.headline).foregroundStyle(.cyan)
                                HStack {
                                    Button("Copy script") { copy(script) }
                                    Button("Run script") {
                                        copy(script)
                                        openApp("MacSploit", success: "Script copied. MacSploit opened. Paste the script there to run it.")
                                    }.buttonStyle(.borderedProminent).tint(.cyan)
                                    Spacer()
                                    Button("Edit") { editing = script }
                                    Button("Delete", role: .destructive) { pendingDelete = script }
                                }
                            }.padding(14).frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                }
            }
            Text("Run script copies your code and opens MacSploit. Paste it there to execute.")
                .font(.caption).foregroundStyle(.secondary)
        }
    }

    private var appsPage: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Apps").font(.largeTitle.bold())
            GroupBox {
                HStack(spacing: 16) {
                    Image(systemName: "bubble.left.and.bubble.right.fill").font(.largeTitle).foregroundStyle(.indigo)
                    Text("Discord").font(.title3.bold())
                    Spacer()
                    Button("Open Discord") { openApp("Discord", success: "Discord opened.") }
                        .buttonStyle(.borderedProminent)
                }.padding(16)
            }
            GroupBox {
                VStack(alignment: .leading, spacing: 15) {
                    Label("RobloxPlayer / your file", systemImage: "app.fill").font(.title3.bold())
                    Text(launcherPath.isEmpty ? "Choose the file or app on your Mac once to save its location." : launcherPath)
                        .font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                    HStack {
                        Button(launcherPath.isEmpty ? "Choose file…" : "Change file…") { chooseFile() }
                        Button("Open file") { openFile() }
                            .buttonStyle(.borderedProminent).disabled(launcherPath.isEmpty)
                    }
                }.padding(16).frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private func copy(_ script: SavedScript) {
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(script.code, forType: .string)
        status = "Copied \(script.name)."
    }

    private func openApp(_ name: String, success: String) {
        let candidates = ["/Applications/\(name).app", NSHomeDirectory() + "/Applications/\(name).app"]
        guard let path = candidates.first(where: { FileManager.default.fileExists(atPath: $0) }) else {
            let panel = NSOpenPanel()
            panel.title = "Locate \(name).app"
            panel.allowedContentTypes = [.applicationBundle]
            panel.canChooseDirectories = false
            panel.allowsMultipleSelection = false
            guard panel.runModal() == .OK, let url = panel.url else { return }
            launchApp(url, success: success)
            return
        }
        launchApp(URL(fileURLWithPath: path), success: success)
    }

    private func launchApp(_ url: URL, success: String) {
        NSWorkspace.shared.openApplication(at: url, configuration: NSWorkspace.OpenConfiguration()) { _, error in
            DispatchQueue.main.async {
                if let error = error { library.error = error.localizedDescription }
                else { status = success }
            }
        }
    }

    private func chooseFile() {
        let panel = NSOpenPanel()
        panel.title = "Choose RobloxPlayer or another file on your Mac"
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = false
        if panel.runModal() == .OK, let url = panel.url {
            launcherPath = url.path
            status = "Saved file shortcut."
        }
    }

    private func openFile() {
        let url = URL(fileURLWithPath: launcherPath)
        guard FileManager.default.fileExists(atPath: launcherPath) else {
            library.error = "This file has moved or was deleted. Press Change file to select it again."
            return
        }
        if url.pathExtension == "app" {
            launchApp(url, success: "Opened \(url.lastPathComponent).")
        } else if FileManager.default.isExecutableFile(atPath: launcherPath) {
            do {
                let process = Process()
                process.executableURL = url
                process.currentDirectoryURL = url.deletingLastPathComponent()
                try process.run()
                status = "Started \(url.lastPathComponent)."
            } catch { library.error = error.localizedDescription }
        } else if NSWorkspace.shared.open(url) {
            status = "Opened \(url.lastPathComponent)."
        } else {
            library.error = "macOS could not open this file. Try selecting its original application bundle."
        }
    }
}

struct ScriptEditor: View {
    @Environment(\.dismiss) private var dismiss
    @State var script: SavedScript
    let onSave: (SavedScript) throws -> Void
    @State private var error: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(script.name.isEmpty ? "Add script" : "Edit script").font(.title2.bold())
            TextField("Script name", text: $script.name).textFieldStyle(.roundedBorder)
            Text("Script code").font(.headline)
            TextEditor(text: $script.code).font(.system(.body, design: .monospaced))
                .border(Color.gray.opacity(0.3)).frame(minHeight: 280)
            if let error = error { Text(error).foregroundStyle(.red).textSelection(.enabled) }
            HStack {
                Button("Import script file…") { importScript() }
                Spacer()
                Button("Cancel") { dismiss() }.keyboardShortcut(.cancelAction)
                Button("Save script") {
                    var saved = script
                    saved.name = saved.name.trimmingCharacters(in: .whitespacesAndNewlines)
                    do { try onSave(saved); dismiss() }
                    catch { self.error = error.localizedDescription }
                }
                .buttonStyle(.borderedProminent).keyboardShortcut("s", modifiers: .command)
                .disabled(script.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || script.code.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }.padding(24).frame(width: 650, height: 510)
    }

    private func importScript() {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = false
        guard panel.runModal() == .OK, let url = panel.url else { return }
        do {
            script.code = try String(contentsOf: url, encoding: .utf8)
            if script.name.isEmpty { script.name = url.deletingPathExtension().lastPathComponent }
        } catch { self.error = "Could not read this file as UTF-8 text. \(error.localizedDescription)" }
    }
}
