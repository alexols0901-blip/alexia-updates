# Alexia HUB Personal

Requires macOS 13+ and Apple developer command-line tools.

## Build and install

1. Unzip this folder.
2. Quit the previous Alexia HUB app.
3. Open Terminal, type `bash` followed by one space, drag this folder’s Build.command into Terminal, and press Return.
4. After compilation the personal app opens. Move dist/Alexia HUB Personal.app into Applications.

## Scripts

Press Add script, enter a name and paste the code, then Save script. You can also import a UTF-8 script file. Every script appears with an icon and Copy script, Run script, Edit and Delete controls. Delete asks for confirmation.

Run script copies the selected script and opens MacSploit. Paste and execute in MacSploit. Install MacSploit separately. If it is outside /Applications or ~/Applications, select its app bundle when prompted.

Scripts are stored locally in ~/Library/Application Support/AlexiaHubPersonal/scripts.json. Copy this file to back up your library. Keep private scripts and credentials in mind when using the clipboard.

## Apps

Open Discord launches the installed Discord app. If it is outside the usual Applications folders, select it when prompted.

Choose file selects the RobloxPlayer executable or another file from your Mac. Its location is remembered. Open file launches it. Use Change file if you move it. Choose the original Roblox.app bundle if its internal executable cannot start independently. The uploaded Roblox binary is not included in this project.

## Verification

Package structure, ZIP integrity and build script shell syntax checked. This project was created in a Linux environment and could not be compiled against the macOS SDK here. Compile it on your Mac with Build.command and share any compiler errors.

## In-app updater (1.1.0)

Build this version once using Build.command. Future source ZIPs can be installed via Updates > Choose update ZIP. The app validates the archive layout, compiles in a temporary folder, signs the new app, and offers Install and restart. It retains the previous bundle until the replacement has been opened. Saved scripts stay in Application Support and the file shortcut remains in preferences.

The app requires the Apple command-line tools for every source update. No Terminal interaction is needed for updates installed through the app.

Online update checks are implemented but require an HTTPS release feed. This project includes no hosted feed. Configure its URL in Updates. The app checks at launch and hourly, then displays Update available. Installation requires clicking Install and restart. Feed URLs and downloads must use the same HTTPS host. The feed needs version, url and sha256 fields. Publish a source ZIP with exactly one AlexiaHubPersonal directory, then compute its SHA-256 and publish the feed JSON after the ZIP is uploaded. The source version constant and release.json must both match the new version. The app trusts the configured feed publisher to supply executable application source.

Local update ZIPs require explicit selection and confirmation. Select only trusted Alexia HUB releases. This updater and app still require on-Mac compilation and restart testing.

## Version 1.1.1

Made sidebar items visible full-width buttons with rectangular hit targets covering the icon, label and empty space. macOS compilation and interactive click testing remain to be completed on the Mac.
